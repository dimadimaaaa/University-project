
<?php require 'auth.php'; require 'db.php'; include 'partials/header.php';
$res = $conn->query("SELECT * FROM categories ORDER BY id DESC");
?>
<h2>عرض الفئات</h2>
<table>
  <thead><tr><th>#</th><th>الاسم</th><th>تاريخ الإضافة</th></tr></thead>
  <tbody>
    <?php while($row=$res->fetch_assoc()): ?>
      <tr>
        <td><?=$row['id']?></td>
        <td><?=htmlspecialchars($row['name'])?></td>
        <td><?=$row['created_at']?></td>
      </tr>
    <?php endwhile; ?>
  </tbody>
</table>
<?php include 'partials/footer.php'; ?>
