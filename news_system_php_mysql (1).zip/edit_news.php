
<?php require 'auth.php'; require 'db.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM news WHERE id=? LIMIT 1");
$stmt->bind_param("i",$id); $stmt->execute(); $news = $stmt->get_result()->fetch_assoc();
if(!$news){ header("Location: view_news.php"); exit; }
$cats = $conn->query("SELECT id,name FROM categories ORDER BY name ASC");
$msg=""; $err="";
if($_SERVER['REQUEST_METHOD']==='POST'){
  $title = trim($_POST['title'] ?? '');
  $category_id = intval($_POST['category_id'] ?? 0);
  $details = trim($_POST['details'] ?? '');
  $imagePath = $news['image'];

  if(isset($_FILES['image']) && $_FILES['image']['error']==UPLOAD_ERR_OK){
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $fname = uniqid("img_").".".$ext;
    $dest = __DIR__."/uploads/".$fname;
    if(move_uploaded_file($_FILES['image']['tmp_name'], $dest)){
      $imagePath = "uploads/".$fname;
    }
  }

  if(!$title || !$category_id || !$details){ $err="الرجاء تعبئة جميع الحقول"; }
  else{
    $stmt2 = $conn->prepare("UPDATE news SET title=?, category_id=?, details=?, image=? WHERE id=?");
    $stmt2->bind_param("sissi", $title, $category_id, $details, $imagePath, $id);
    if($stmt2->execute()){ $msg="تم تعديل الخبر"; } else { $err="حصل خطأ أثناء التعديل"; }
  }
}
include 'partials/header.php';
?>
<h2>تعديل خبر</h2>
<?php if($msg): ?><div class="badge badge-green"><?=$msg?></div><?php endif; ?>
<?php if($err): ?><div class="badge badge-red"><?=$err?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data">
  <div class="row">
    <div>
      <label>العنوان</label>
      <input type="text" name="title" value="<?=htmlspecialchars($news['title'])?>" required>
    </div>
    <div>
      <label>الفئة</label>
      <select name="category_id" required>
        <?php while($c=$cats->fetch_assoc()): ?>
          <option value="<?=$c['id']?>" <?=$c['id']==$news['category_id']?'selected':''?>>
            <?=htmlspecialchars($c['name'])?>
          </option>
        <?php endwhile; ?>
      </select>
    </div>
  </div>
  <div class="row">
    <div>
      <label>تفاصيل الخبر</label>
      <textarea name="details" rows="6" required><?=htmlspecialchars($news['details'])?></textarea>
    </div>
    <div>
      <label>صورة الخبر (اتركها فارغة للإبقاء على الحالية)</label>
      <input type="file" name="image" accept="image/*">
      <?php if($news['image']): ?><br><img src="<?=$news['image']?>" style="height:60px"><?php endif; ?>
    </div>
  </div>
  <br>
  <button class="btn btn-primary">حفظ التعديلات</button>
  <a class="btn" href="view_news.php">رجوع</a>
</form>
<?php include 'partials/footer.php'; ?>
