
<?php if (session_status() === PHP_SESSION_NONE) { session_start(); } ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>نظام إدارة الأخبار</title>
  <style>
    body{font-family: Tahoma, Arial, sans-serif; margin:0; background:#f7f7f7; color:#222}
    header, footer{background:#111;color:#fff;padding:12px 16px}
    a{color:#0a58ca;text-decoration:none}
    .container{max-width:1100px;margin:20px auto;padding:16px;background:#fff;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.06)}
    nav a{margin:0 8px;color:#eee}
    table{width:100%;border-collapse:collapse;margin-top:12px}
    th,td{border:1px solid #ddd;padding:8px}
    th{background:#f0f0f0}
    .btn{display:inline-block;padding:6px 10px;border-radius:6px;border:1px solid #ccc;background:#fafafa}
    .btn-primary{background:#0d6efd;color:#fff;border-color:#0d6efd}
    .btn-danger{background:#dc3545;color:#fff;border-color:#dc3545}
    .btn-warning{background:#ffc107;color:#000;border-color:#ffc107}
    .badge{display:inline-block;padding:3px 8px;border-radius:9999px;font-size:12px}
    .badge-green{background:#d1fae5;color:#065f46}
    .badge-red{background:#fee2e2;color:#991b1b}
    form .row{display:flex;gap:12px;flex-wrap:wrap}
    form .row > div{flex:1 1 300px}
    input[type=text], input[type=email], input[type=password], select, textarea{
      width:100%; padding:8px; border:1px solid #ccc; border-radius:6px
    }
  </style>
</head>
<body>
<header>
  <strong>نظام إدارة الأخبار</strong>
  <nav style="float:left">
    <?php if(isset($_SESSION['user_id'])): ?>
      <a href="dashboard.php">لوحة التحكم</a>
      <a href="add_category.php">إضافة فئة</a>
      <a href="view_categories.php">عرض الفئات</a>
      <a href="add_news.php">إضافة خبر</a>
      <a href="view_news.php">عرض الأخبار</a>
      <a href="deleted_news.php">الأخبار المحذوفة</a>
      <a href="logout.php">تسجيل الخروج</a>
    <?php else: ?>
      <a href="login.php">تسجيل الدخول</a>
      <a href="register.php">إنشاء حساب</a>
    <?php endif; ?>
  </nav>
  <div style="clear:both"></div>
</header>
<main class="container">
