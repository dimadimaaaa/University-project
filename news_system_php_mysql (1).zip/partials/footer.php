
</main>
<footer>
  <small>مشروع جامعي بسيط - PHP + MySQL</small>
</footer>
</body>
</html>
