
<?php
require 'db.php';
session_start();
$err = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $name = trim($_POST['name'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  $confirm  = $_POST['confirm'] ?? '';

  if(!$name || !$email || !$password){ $err = "الرجاء تعبئة جميع الحقول"; }
  elseif($password !== $confirm){ $err = "كلمتا المرور غير متطابقتين"; }
  else {
    $stmt = $conn->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows>0){ $err = "هذا الايميل مسجل مسبقًا"; }
    else{
      $hash = password_hash($password, PASSWORD_BCRYPT);
      $ins = $conn->prepare("INSERT INTO users(name,email,password) VALUES (?,?,?)");
      $ins->bind_param("sss", $name, $email, $hash);
      if($ins->execute()){
        $_SESSION['user_id'] = $ins->insert_id;
        $_SESSION['user_name'] = $name;
        header("Location: dashboard.php"); exit;
      } else { $err = "حصل خطأ أثناء التسجيل"; }
    }
  }
}
include 'partials/header.php';
?>
<h2>إنشاء حساب</h2>
<?php if($err): ?><div style="color:#b91c1c;background:#fee2e2;padding:8px;border-radius:6px"><?=$err?></div><?php endif; ?>
<form method="post">
  <div class="row">
    <div>
      <label>الاسم</label>
      <input type="text" name="name" required>
    </div>
    <div>
      <label>الإيميل</label>
      <input type="email" name="email" required>
    </div>
    <div>
      <label>كلمة المرور</label>
      <input type="password" name="password" required>
    </div>
    <div>
      <label>تأكيد كلمة المرور</label>
      <input type="password" name="confirm" required>
    </div>
  </div>
  <br>
  <button class="btn btn-primary" type="submit">تسجيل</button>
  <a class="btn" href="login.php">لديك حساب؟ تسجيل الدخول</a>
</form>
<?php include 'partials/footer.php'; ?>
