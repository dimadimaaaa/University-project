
<?php require 'auth.php'; require 'db.php';
$msg=""; $err="";
$cats = $conn->query("SELECT id,name FROM categories ORDER BY name ASC");
if($_SERVER['REQUEST_METHOD']==='POST'){
  $title = trim($_POST['title'] ?? '');
  $category_id = intval($_POST['category_id'] ?? 0);
  $details = trim($_POST['details'] ?? '');
  $user_id = $_SESSION['user_id'];
  $imagePath = NULL;

  if(isset($_FILES['image']) && $_FILES['image']['error']==UPLOAD_ERR_OK){
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $fname = uniqid("img_").".".$ext;
    $dest = __DIR__."/uploads/".$fname;
    if(move_uploaded_file($_FILES['image']['tmp_name'], $dest)){
      $imagePath = "uploads/".$fname;
    }
  }

  if(!$title || !$category_id || !$details){ $err="الرجاء تعبئة جميع الحقول"; }
  else{
    $stmt = $conn->prepare("INSERT INTO news(title,category_id,details,image,user_id) VALUES(?,?,?,?,?)");
    $stmt->bind_param("sissi", $title, $category_id, $details, $imagePath, $user_id);
    if($stmt->execute()){ $msg="تم إضافة الخبر بنجاح"; } else { $err="حصل خطأ أثناء الحفظ"; }
  }
}
include 'partials/header.php';
?>
<h2>إضافة خبر</h2>
<?php if($msg): ?><div class="badge badge-green"><?=$msg?></div><?php endif; ?>
<?php if($err): ?><div class="badge badge-red"><?=$err?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data">
  <div class="row">
    <div>
      <label>العنوان</label>
      <input type="text" name="title" required>
    </div>
    <div>
      <label>الفئة</label>
      <select name="category_id" required>
        <option value="">— اختر —</option>
        <?php while($c=$cats->fetch_assoc()): ?>
          <option value="<?=$c['id']?>"><?=htmlspecialchars($c['name'])?></option>
        <?php endwhile; ?>
      </select>
    </div>
  </div>
  <div class="row">
    <div>
      <label>تفاصيل الخبر</label>
      <textarea name="details" rows="6" required></textarea>
    </div>
    <div>
      <label>صورة الخبر (اختياري)</label>
      <input type="file" name="image" accept="image/*">
    </div>
  </div>
  <br>
  <button class="btn btn-primary">حفظ</button>
</form>
<?php include 'partials/footer.php'; ?>
