
<?php require 'auth.php'; require 'db.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $conn->prepare("UPDATE news SET status='deleted' WHERE id=?");
$stmt->bind_param("i",$id); $stmt->execute();
header("Location: view_news.php");
