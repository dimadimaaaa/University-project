
<?php
require 'db.php';
session_start();
$err = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email=? LIMIT 1");
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $res = $stmt->get_result();
  if($user = $res->fetch_assoc()){
    if(password_verify($password, $user['password'])){
      $_SESSION['user_id'] = $user['id'];
      $_SESSION['user_name'] = $user['name'];
      header("Location: dashboard.php"); exit;
    }
  }
  $err = "بيانات الدخول غير صحيحة";
}
include 'partials/header.php';
?>
<h2>تسجيل الدخول</h2>
<?php if($err): ?><div style="color:#b91c1c;background:#fee2e2;padding:8px;border-radius:6px"><?=$err?></div><?php endif; ?>
<form method="post">
  <div class="row">
    <div>
      <label>الإيميل</label>
      <input type="email" name="email" required>
    </div>
    <div>
      <label>كلمة المرور</label>
      <input type="password" name="password" required>
    </div>
  </div>
  <br>
  <button class="btn btn-primary" type="submit">دخول</button>
  <a class="btn" href="register.php">مستخدم جديد؟ إنشاء حساب</a>
</form>
<?php include 'partials/footer.php'; ?>
