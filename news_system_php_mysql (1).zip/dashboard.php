
<?php require 'auth.php'; include 'partials/header.php'; ?>
<h2>لوحة التحكم</h2>
<p>أهلًا، <?=htmlspecialchars($_SESSION['user_name'] ?? 'مستخدم')?> 👋</p>
<ul>
  <li><a href="add_category.php">إضافة فئة</a></li>
  <li><a href="view_categories.php">عرض الفئات</a></li>
  <li><a href="add_news.php">إضافة خبر</a></li>
  <li><a href="view_news.php">عرض الأخبار</a></li>
  <li><a href="deleted_news.php">عرض الأخبار المحذوفة</a></li>
</ul>
<?php include 'partials/footer.php'; ?>
