
# News Management System (PHP + MySQL)

A simple assignment-ready project implementing:
- User registration & login
- Dashboard
- Category CRUD (add + list)
- News CRUD (add + list + soft delete + restore + edit)
- Deleted news view

## Quick Start
1. Create a database (e.g., `news_system`) and import `schema.sql`.
2. Copy this folder to your local PHP server (XAMPP `htdocs` or similar).
3. Update `db.php` connection credentials if needed.
4. Open `http://localhost/news_system/register.php` to create an account, then login.

## Default Paths
- `register.php`, `login.php`, `logout.php`
- `dashboard.php`
- `add_category.php`, `view_categories.php`
- `add_news.php`, `view_news.php`, `edit_news.php`, `delete_news.php`, `restore_news.php`
- `deleted_news.php`

## Image Uploads
- Uploaded images are stored in `/uploads`.
- Max size limited by PHP config; adjust as needed in `php.ini`.
