
<?php require 'auth.php'; require 'db.php'; include 'partials/header.php';
$sql = "SELECT n.*, c.name AS category_name, u.name AS user_name
        FROM news n
        JOIN categories c ON c.id=n.category_id
        JOIN users u ON u.id=n.user_id
        WHERE n.status='active'
        ORDER BY n.id DESC";
$res = $conn->query($sql);
?>
<h2>عرض الأخبار</h2>
<table>
  <thead>
    <tr>
      <th>#</th><th>العنوان</th><th>الفئة</th><th>صورة</th><th>الكاتب</th><th>الحالة</th><th>إجراءات</th>
    </tr>
  </thead>
  <tbody>
    <?php while($row=$res->fetch_assoc()): ?>
      <tr>
        <td><?=$row['id']?></td>
        <td><?=htmlspecialchars($row['title'])?></td>
        <td><?=htmlspecialchars($row['category_name'])?></td>
        <td><?php if($row['image']): ?><img src="<?=$row['image']?>" alt="" style="height:40px"><?php endif; ?></td>
        <td><?=htmlspecialchars($row['user_name'])?></td>
        <td><span class="badge badge-green">نشط</span></td>
        <td>
          <a class="btn btn-warning" href="edit_news.php?id=<?=$row['id']?>">تعديل</a>
          <a class="btn btn-danger" href="delete_news.php?id=<?=$row['id']?>" onclick="return confirm('هل أنت متأكد من الحذف؟')">حذف</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </tbody>
</table>
<?php include 'partials/footer.php'; ?>
