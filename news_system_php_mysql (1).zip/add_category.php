
<?php require 'auth.php'; require 'db.php'; $msg=""; $err="";
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = trim($_POST['name'] ?? '');
  if(!$name){ $err="الرجاء إدخال اسم الفئة"; }
  else{
    $stmt = $conn->prepare("INSERT INTO categories(name) VALUES (?)");
    $stmt->bind_param("s",$name);
    if($stmt->execute()){ $msg="تم إضافة الفئة بنجاح"; } else { $err="حدث خطأ أثناء الحفظ"; }
  }
}
include 'partials/header.php';
?>
<h2>إضافة فئة</h2>
<?php if($msg): ?><div class="badge badge-green"><?=$msg?></div><?php endif; ?>
<?php if($err): ?><div class="badge badge-red"><?=$err?></div><?php endif; ?>
<form method="post">
  <label>اسم الفئة</label>
  <input type="text" name="name" required>
  <br><br>
  <button class="btn btn-primary">حفظ</button>
</form>
<?php include 'partials/footer.php'; ?>
